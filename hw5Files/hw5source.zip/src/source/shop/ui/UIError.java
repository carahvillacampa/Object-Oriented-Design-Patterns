package source.shop.ui;

public class UIError extends Error {
}
