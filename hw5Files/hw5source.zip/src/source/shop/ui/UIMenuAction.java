package source.shop.ui;

public interface UIMenuAction {
  public void run();
}
